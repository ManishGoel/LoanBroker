package org.loanbroker.controller;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.sun.xml.internal.txw2.Document;

import org.loanbroker.form.*;

/**
 * Servlet implementation class UserDataServlet
 */
@Controller
public class RegistrationController {
	private static final long serialVersionUID = 1L;
	private String output = null;
	String fullName = null;
	String ssn = null;
	String amount = null;
	String term = null;
	String email = null;
	String salary = null;
	String bank = null;
	@Value("${mainservicehost}")
	private String mainServiceHost;
	@Value("${validateservicehost}")
	private String validateServiceHost;

    @RequestMapping(value = "/welcome_new", method = RequestMethod.GET)
    public ModelAndView welcome() {
    	return new ModelAndView("welcome", "command", new NewData());
    }
	
    @RequestMapping(value = "/registration", method = RequestMethod.GET)
    public ModelAndView registration() {
    	return new ModelAndView("registration", "command", new LoanData());
    }
    
    @RequestMapping(value = "/findLoan", method = RequestMethod.POST)
    public String addRegistration(@Valid @ModelAttribute("command") LoanData loanData, BindingResult bindingResult, ModelMap model) throws IOException, JSONException {
    	
    	JSONObject serviceResp = null;
    	JSONArray myArray;
    	JSONArray finalArray = null;
    	JSONObject finalobj = null;
    	fullName = loanData.getFullname();
    	ssn = loanData.getSsn();
    	amount = loanData.getAmount();
    	term = loanData.getTerm();
    	email = loanData.getEmail();
    	salary = loanData.getSalary();
    	bank = loanData.getBank();
		ArrayList description = new ArrayList();
		ArrayList emi = new ArrayList();
		ArrayList roi = new ArrayList();
		ArrayList bankName = new ArrayList();
		int serviceCode = 0;
		String servResp = "";
    	
    	if (fullName == "" || ssn == "" || amount == "" || term == "" || email == "" || salary == "" || bank == "") {
    		if (fullName == "")
    			model.addAttribute("errorName", "Name Cannot be empty !!!");
    		if (ssn == "")
    			model.addAttribute("errorSsn", "SSN Cannot be empty !!!");
    		if (amount == "")
    			model.addAttribute("errorAmount", "Amount Cannot be empty !!!");
    		if (term == "")
    			model.addAttribute("errorTerm", "Term Cannot be empty !!!");
    		if (email == "")
    			model.addAttribute("errorEmail", "Email Cannot be empty !!!");
    		if (salary == "")
    			model.addAttribute("errorSalary", "Salary Cannot be empty !!!");
    		if (bank == "")
    			model.addAttribute("errorBank", "Bank Cannot be empty !!!");
    		return "registration";
    	}
    	
    	if (email.indexOf("@") < 0) {
    		model.addAttribute("errorEmail", "Email format is not correct !!!");
    		return "registration";
    	}
    	
    	//URL url = new URL("http://10.103.0.91:8185/sbi/sbirequest?name=" +fullName+ "&ssn=" +ssn+
    	//		"&amount=" +amount+ "&term=" +term+ 
    	//		"&email=" +email+ "&creditScore=" +salary);
    	URL url = new URL(mainServiceHost+"/loanbroker?name=" +fullName+ "&ssn=" +ssn+ "&amount=" +amount+ "&term=" +term+ "&email=" +email+ "&salary=" +salary+ "&bank="+bank);
    	HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept", "application/json");
		
		if (conn.getResponseCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
		
		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) {
			serviceResp = new JSONObject(output);
			System.out.println(output);
		}
    	conn.disconnect();
    	
    	
    	myArray = serviceResp.names();
		for (int i = 0; i < myArray.length(); i++) {
			String myName = myArray.getString(i);
			if (myName.equalsIgnoreCase("bankResponse") && bank.equalsIgnoreCase("all"))
				finalArray = serviceResp.getJSONArray("bankResponse");
			else if (!bank.equalsIgnoreCase("all"))
				finalobj = serviceResp.getJSONObject("bankResponse");
		}
		
		if (null != finalArray && finalArray.length() != 0) {
		for (int i = 0; i < finalArray.length(); i++)
		{
			description.add(i, finalArray.getJSONObject(i).getString("desc"));
			emi.add(i, finalArray.getJSONObject(i).getString("emi"));
			roi.add(i, finalArray.getJSONObject(i).getDouble("roi"));
			bankName.add(i, finalArray.getJSONObject(i).getString("bankName"));
		}
		} else if (null != finalobj && finalobj.length() != 0) {
			description.add(0, finalobj.getString("desc"));
			emi.add(0, finalobj.getString("emi"));
			roi.add(0, finalobj.getDouble("roi"));
			bankName.add(0, finalobj.getString("bankName"));
		}
		else {
			Object myObj = serviceResp.get("code");
			if (myObj.toString().equalsIgnoreCase("500")) {
				serviceCode = serviceResp.getInt("code");
				servResp = serviceResp.getString("desc").toString();
			}
		}
		
    	model.addAttribute("fullname", loanData.getFullname());
    	model.addAttribute("ssn", loanData.getSsn());
    	model.addAttribute("amount", loanData.getAmount());
    	model.addAttribute("term", loanData.getTerm());
    	model.addAttribute("email", loanData.getEmail());
    	model.addAttribute("salary", loanData.getSalary());
    	model.addAttribute("bank", loanData.getBank());
    	model.addAttribute("serviceResponse", serviceResp);
    	model.addAttribute("command", new ResultData(loanData.getFullname(), loanData.getSsn(), 
    			loanData.getAmount(), loanData.getTerm(), loanData.getEmail(), loanData.getSalary())); 
    	model.addAttribute("description", description);
    	model.addAttribute("emi", emi);
    	model.addAttribute("roi", roi);
    	model.addAttribute("bankname", bankName);
    	model.addAttribute("servcode", serviceCode);
    	model.addAttribute("servresp", servResp);
    	return "result";
    }
    
    @RequestMapping(value = "/result", method = RequestMethod.GET)
    public ModelAndView result() {
    	return new ModelAndView("result", "command", new ResultData());
    }
    
    @RequestMapping(value = "/checkEligib", method = RequestMethod.POST)
    public String addResult(@ModelAttribute("command") ResultData resultData, ModelMap model) throws IOException, JSONException {
    	JSONObject serviceResp = null;
    	String bankName = resultData.getBank();
		int serviceCode = 0;
		String servResp = "";
		String servReason = "";

    	URL url = new URL(validateServiceHost+"/brokerapproval?name=" +fullName+ "&ssn=" +ssn+ "&amount=" +amount+ "&term=" +term+ "&salary=" +salary+ "&bank="+bankName+ "&roi=1.2");
    	HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept", "application/json");
		if (conn.getResponseCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}
		
		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
		System.out.println("Output from Server .... \n");
		output = br.readLine();
		if (output  != null) {
			serviceResp = new JSONObject(output);
			System.out.println(output);
		}
    	conn.disconnect();
		
    	
    	Object myObj = serviceResp.get("code");
		serviceCode = serviceResp.getInt("code");
		servResp = serviceResp.getString("response").toString();
		if (serviceResp.has("reason") && !serviceResp.get("reason").equals(null))
			servReason = serviceResp.get("reason").toString();
		else
			servReason = "";
		
    	model.addAttribute("bankname", bankName);
    	model.addAttribute("servcode", serviceCode);
    	model.addAttribute("servresp", servResp);
    	model.addAttribute("servreason", servReason);
    	return "bankresponse";
    }
    
    @RequestMapping(value = "/existUser", method = RequestMethod.POST)
    public String existUser(@ModelAttribute("command") LoanData loanData, NewData newData , ModelMap model) {
    	
    	String userId = newData.getUserid();
    	String pwd = newData.getPwd();
    	System.out.println(userId + pwd);
    	
    	model.addAttribute("userid", userId);
    	model.addAttribute("pwd", pwd);
    	return "registration";
    }
    
    @RequestMapping(value = "/newUser", method = RequestMethod.POST)
    public String newUser(@ModelAttribute("command") LoanData loanData, RegisterData registerData , ModelMap model) {
    	
    	String userId = registerData.getUserid();
    	String pwd = registerData.getPwd();
    	String firstName = registerData.getFirstname();
    	String lastName = registerData.getLastname();
    	String dateofbirth = registerData.getDob();
    	
    	
    	System.out.println(userId + pwd + firstName + lastName + dateofbirth);
    	
    	model.addAttribute("userid", userId);
    	model.addAttribute("pwd", pwd);
    	return "registration";
    }    

    @RequestMapping(value = "/welcome_newww", method = RequestMethod.GET)
    public ModelAndView welcomeNew() {
    	return new ModelAndView("newuser", "command", new RegisterData());
    }
    
    @RequestMapping(value = "/contact", method = RequestMethod.GET)
    public ModelAndView contact() {
    	return new ModelAndView("contact", "command", new RegisterData());
    }
}
