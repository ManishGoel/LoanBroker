package org.capgemini.loanbroker.services;

import java.io.Serializable;

public class BankServiceICICI implements Serializable{

	
    private static final long serialVersionUID = 4108271137166107769L;
    
    private BankUtility bankUtil = new BankUtility();
    private double iciciInterest = 9.4;
	private double emi = 0.0;
	
	public ServiceResponse getLoanStatus(String name, int ssn, Long amount, int term, String email) {

		System.out.println("ICICI Request Recieved : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email);
		ServiceResponse myResponse = new ServiceResponse();

		myResponse.setName(name);
		myResponse.setSsn(ssn);
		myResponse.setAmount(amount);
		myResponse.setTerm(term);
		myResponse.setEmail(email);
		
	
		
		
			emi = bankUtil.calculateEMI(amount, term, iciciInterest);
			
			myResponse.setInterest(iciciInterest);
			myResponse.setEMI(emi);
			myResponse.setStatus("Congratulations, your loan can be processed with ICICI");
		
		System.out.println("ICICI Response sent : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email+ " ,EMI = " +emi+ " ,interest = " +iciciInterest);
		
		return myResponse;
	}
	
}
