package org.capgemini.loanbroker.services;

import java.io.Serializable;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/sbirequest")
public class BankServiceSBI implements Serializable{

	/**
     * Serial version
     */
    private static final long serialVersionUID = 4108271137166107769L;
    
    private BankUtility bankUtil = new BankUtility();
	private double sbiInterest = 9.0;
	private double emi = 0.0;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ServiceResponse getLoanStatus(@QueryParam("name") String name, @QueryParam("ssn") int ssn, 
			@QueryParam("amount") Long amount, @QueryParam("term") int term, 
			@QueryParam("email") String email) {

		System.out.println("SBI Request Recieved : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email);
		
		ServiceResponse myResponse = new ServiceResponse();

		myResponse.setName(name);
		myResponse.setSsn(ssn);
		myResponse.setAmount(amount);
		myResponse.setTerm(term);
		myResponse.setEmail(email);
		
		
	
			emi = bankUtil.calculateEMI(amount, term, sbiInterest);
			
			myResponse.setInterest(sbiInterest);
			myResponse.setEMI(emi);	
			myResponse.setStatus("Congratulations, your loan can be processed with SBI");

		
		System.out.println("SBI Response sent : Input Parameters are :: Name = " +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term+ " ,email = " +email+" ,EMI = " +emi+ " ,interest = " +sbiInterest);
		
		return myResponse;
	}
}
