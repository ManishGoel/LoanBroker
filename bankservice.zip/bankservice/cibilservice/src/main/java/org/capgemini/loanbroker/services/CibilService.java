package org.capgemini.loanbroker.services;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/cibilrequest")
public class CibilService implements Serializable{

    private static final long serialVersionUID = 4108271137166107769L;
    
    private BankUtility bankUtil = new BankUtility();
    
	private double sbiInterest = 9.0;
	private int sbiCreditScore = 900;
	private double emi = 0.0;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ServiceResponse getCreditScore(@QueryParam("name") String name, @QueryParam("ssn") int ssn, 
			@QueryParam("amount") Long amount, @QueryParam("term") int term) {

		System.out.println("Cibil Request Recieved : Input Parameters are :: Name =" +name+ " ,SSN = " +ssn+ " ,"
				+ "amount = " +amount+ " ,term = " +term);
		
		ServiceResponse myResponse = new ServiceResponse();

		myResponse.setName(name);
		myResponse.setSsn(ssn);
		myResponse.setAmount(amount);
		myResponse.setTerm(term);
		List<String> creditNames= new ArrayList<String>();
		creditNames.add("gaurav");
		creditNames.add("shyam");
		creditNames.add("manish");
		if(creditNames.contains(name))
			myResponse.setCreditScore(900);
		else
			myResponse.setCreditScore(700);
		
		return myResponse;
	}
}
