package org.capgemini.loanbroker.validator;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;

public class LoanApprovalValidator implements Validator{

	public LoanApprovalValidator()
	{}	
	
	@Override
	public ValidationResult validate(MuleEvent event){

		 
		System.out.println("&&& IN LoanApprovalValidator &&&& event="+event);
		
		Long amount = Long.parseLong(event.getFlowVariable("amount"));
		Long salary = Long.parseLong(event.getFlowVariable("salary"));
		Long term = Long.parseLong(event.getFlowVariable("term"));
		String bank = event.getFlowVariable("bank");
		

		System.out.println("salary="+salary+":amount="+amount+":term="+term);
		//
		if(term<2)
		{
			return ImmutableValidationResult.error("-----Loan is rejected.----");
		}
		if(salary> 90)
		{
			//Message message = new Message("EMAIL PAYLOAD EXCEPTION",500,event.getFlowVariable("email"));
			//event.getMessage().setPayload("----------EMAIL PAYLOAD EXCEPTION------------------");
			return ImmutableValidationResult.error("-----LOAN IS NOT CORRECT----");
			
		}	
		
		/*if(!banks.contains(event.getFlowVariable("bank")))
		{
			event.getMessage().setPayload("----------BANK PAYLOAD EXCEPTION------------------");
			return ImmutableValidationResult.error("-----BANK NAME IS NOT CORRECT----");
			
		}		*/
		return ImmutableValidationResult.ok();
}
	
}
