package com.testcase.test.loanapproval;


import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.junit.Test;
import org.mule.api.MuleMessage;
import org.mule.module.client.MuleClient;
import org.mule.tck.junit4.FunctionalTestCase;

public class NextTestCase extends FunctionalTestCase
{

    private static final String OK_REQUEST_APP_NAME = "okRequestApp";
    private static final String NO_CONTENT_REQUEST_APP_NAME = "noContentRequestApp";
   
    protected String getConfigResources() {
    	System.out.println("--inside getConfigResources	----");
        return "./src/main/app/loanapproval.xml";
        
    }
   	
    @Test
    public void testSharedResource() throws Exception
    {
    	System.out.println("--inside testSharedResource----");
       
    	 MuleClient client = new MuleClient(muleContext);
    	    String expected = "gaurav";
    	    Map<String, Object> properties = null;
    	    MuleMessage result = client.send("http://lin51004751:8084/loan/getapproval?name=gaurav&ssn=12&amount=1500000&term=18&salary=9000000&bank=sbi&roi=1.2", null, properties);
    	    System.out.println("-result.getPayload()1----"+result.getPayload());
    	    System.out.println("-result.getPayload()2----"+result.getPayloadAsString());
    	   // System.out.println("-expected----"+expected);
    	   assertEquals(result.getPayloadAsString(), result.getPayloadAsString());
    	
    	
      /*  MuleMessage responseFromFirstApp = getResponseFromApp("http://10.103.0.72:8089/next", OK_REQUEST_APP_NAME);
        assertThat(responseFromFirstApp.getPayloadAsString(), is("200"));

        //test bad request app
        MuleMessage responseFromSecondApp = getResponseFromApp("vm://doRequest", NO_CONTENT_REQUEST_APP_NAME);
        assertThat(responseFromSecondApp.getPayloadAsString(), is("204"));*/
    }

   /* private MuleMessage getResponseFromApp(String url, String appName) throws MuleException
    {
    	System.out.println("--inside getResponseFromApp----");
    
    	MuleContext muleContext = getMuleContextForApp(appName);
        MuleMessage testMessage = new DefaultMuleMessage(null, muleContext);

        return muleContext.getClient().send(url, testMessage);
    }*/


	

	

}