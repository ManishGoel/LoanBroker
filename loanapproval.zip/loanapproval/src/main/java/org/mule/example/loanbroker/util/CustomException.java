package org.mule.example.loanbroker.util;

import org.mule.message.DefaultExceptionPayload;

public class CustomException extends Exception {

	public CustomException(Exception exception) {
		DefaultExceptionPayload defaultExceptionPayload = new DefaultExceptionPayload(exception);
		
	}
}
