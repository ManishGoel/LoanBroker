package org.mule.example.loanbroker.util;

public class BankApprovalException extends Exception  {
	

	private String response;	
	private static final long serialVersionUID = 4664456874499611218L;
	
    private int errorCode;
  
    public BankApprovalException(String response,int errorCode)
    {	
    	super(response);
    	//super(response,throwable);
    	this.response = response;
    	this.errorCode = errorCode;
/*    	DefaultExceptionPayload defaultExceptionPayload =new DefaultExceptionPayload(this);
    	System.out.println("customException.getException()="+defaultExceptionPayload);
*/    	
    }
   
    
     public int getErrorCode(){
        return this.errorCode;
    }

     
     public void setErrorcode(int errorCode) {
 		this.errorCode = errorCode;
 	}
     
	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
	
	/*	
	public int getErrorcode() {
		return errorcode;
	}
	
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}*/
}
