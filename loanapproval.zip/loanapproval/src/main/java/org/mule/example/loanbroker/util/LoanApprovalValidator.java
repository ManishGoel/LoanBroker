package org.mule.example.loanbroker.util;

import java.util.Map;

import org.mule.api.MuleEvent;
import org.mule.extension.validation.api.ValidationException;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;

public class LoanApprovalValidator implements Validator{

	public LoanApprovalValidator()
	{}
	
	@Override
	public ValidationResult validate(MuleEvent event) {
		ValidationResult validationResult = null;
		
		System.out.println("&&& IN LoanApprovalValidator &&&& event="+event);
		
		Map payloadMap = (Map)event.getMessage().getPayload();
		
		
		/*BusinessService businessService = new BusinessService();
		businessService.process();
		System.out.println("credit_score="+payloadMap.get("credit_score"));*/
	
		if(Integer.parseInt(payloadMap.get("credit_score").toString()) < 750)
		{
			//Message message = new Message("EMAIL PAYLOAD EXCEPTION",500,event.getFlowVariable("email"));
			//event.getMessage().setPayload("----------EMAIL PAYLOAD EXCEPTION------------------");
			
			
		/*	try {
				throw new ValidationException(validationResult, event);
			} catch (ValidationException e) {
				
			}*/
			
				//throw new BankApprovalException(501,"Credit score is less");
			
			
			//return ImmutableValidationResult.error("-----CREDIT SCORE IS LESS THAN 750----");
		}	
	
		return ImmutableValidationResult.ok();
}
	
}
