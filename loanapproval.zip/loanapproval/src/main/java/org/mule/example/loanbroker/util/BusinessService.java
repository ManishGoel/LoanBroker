package org.mule.example.loanbroker.util;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class BusinessService implements Callable
{
	@Override
	public Object onCall(MuleEventContext eventContext) throws BankApprovalException {
		 
			
		Map payloadMap = (Map)eventContext.getMessage().getPayload();
		//BankApprovalException bankApprovalException =new BankApprovalException( response,int errorCode,Throwable cause)
		System.out.println("payloadMap. in BUSINESS SERVICE="+payloadMap);
		System.out.println("payloadMap.getcredit_score="+payloadMap.get("credit_score"));	
		if(payloadMap!=null && payloadMap.get("credit_score")!=null && 
			Integer.parseInt(payloadMap.get("credit_score").toString()) < 750)
		{
					
					throw new BankApprovalException("kiop",501);
		}
		return payloadMap;
	}
}
