package org.mule.example.loanbroker.cibil;


public class CibilService implements ICibil
{
     public int getCreditScore(Integer ssn)	
     {
         Integer credit_score;

         credit_score = (int)(Math.random() * 600 + 300);

         return 900;
     }
     
     
     protected int getCreditHistoryLength(int ssn)
     {
         int credit_history_length;

         credit_history_length = (int)(Math.random() * 19 + 1);

         return credit_history_length;
     }

     
}
