package org.mule.example.loanbroker.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.mule.DefaultMuleEvent;
import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.routing.AggregationContext;
import org.mule.example.loanbroker.bank.BankResponse;
import org.mule.routing.AggregationStrategy;

public class BankResponseAggregationStrategy implements AggregationStrategy{

	@Override
	public MuleEvent aggregate(AggregationContext context) throws MuleException {
		
		 MuleEvent result = context.getOriginalEvent();

		 List<BankResponse> bankResponses = new ArrayList<BankResponse>();
		 List<BankResponse> resultBankResponses = new ArrayList<BankResponse>();
	        
	        for (MuleEvent event : context.collectEventsWithoutExceptions()) {
	        	BankResponse bankResponse = (BankResponse) event.getMessage().getPayload();
	        	bankResponses.add(bankResponse);
	        	 //result = DefaultMuleEvent.copy(event);
	        }
	        
	        Collections.sort(bankResponses,new MyROIComprator());
	        System.out.println("bankResponses="+bankResponses);
	        int count=0;
	        for (BankResponse bankResponse : bankResponses) {
	        	if(count<2)
	        	{
	        		resultBankResponses.add(bankResponse);
		        	count++;
	        	}
			}
	        
	        result.getMessage().setPayload(resultBankResponses);
	        try {
				System.out.println("result SIZE="+result.getMessage().getPayloadAsString());
			} catch (Exception e) {
				e.printStackTrace();
			}
	        if (result != null)  {
	            return result;
	        }
	        throw new  RuntimeException("no Bank Response obtained");
	}
}
