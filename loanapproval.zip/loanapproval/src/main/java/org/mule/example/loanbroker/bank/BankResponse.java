package org.mule.example.loanbroker.bank;

public class BankResponse {
	private String desc;
	private Double emi;
	private Double roi;
	private String bankName;
	
	
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Double getEmi() {
		return emi;
	}
	public void setEmi(Double emi) {
		this.emi = emi;
	}
	public Double getRoi() {
		return roi;
	}
	public void setRoi(Double roi) {
		this.roi = roi;
	}
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public String toString()
	{
		return "----Desc="+desc+":roi="+roi+":emi="+emi+":bankName="+bankName+"------------";
	}
}