package org.mule.example.loanbroker.cibil;


import javax.jws.WebService;


@WebService
public interface ICibil
{
    int getCreditScore(Integer ssn	);
}
