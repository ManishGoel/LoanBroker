package org.mule.example.loanbroker.util;

import java.util.ArrayList;
import java.util.List;

import org.mule.api.MuleEvent;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;

public class BankValidator implements Validator{

	public BankValidator()
	{}
	
	@Override
	public ValidationResult validate(MuleEvent event) {
/*
		Properties prop = new Properties();
		try {
			InputStream input = BankValidator.class.getClassLoader().getResourceAsStream("smtp.properties");            
	        prop.load(input);
	        System.out.println("======PROP="+prop.getProperty("smtp"));
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
*/	
		List<String> banks = new ArrayList<>();
		banks.add("icici");
		banks.add("sbi");
		banks.add("hdfc");
		banks.add("all");
		
		
		if(!event.getFlowVariable("email").toString().contains("@"))
			return ImmutableValidationResult.error("-----EMAIL IS NOT CORRECT----");
		
		if(!banks.contains(event.getFlowVariable("bank")))
		{
			event.getMessage().setPayload("----------BANK PAYLOAD EXCEPTION------------------");
			return ImmutableValidationResult.error("-----BANK NAME IS NOT CORRECT----");
		}		
		return ImmutableValidationResult.ok();
	}
}