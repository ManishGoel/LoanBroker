package org.mule.example.loanbroker.cibil;

public class CibilResponse {
	
	private Integer ssn;
	private String name;
	private Integer credit_score;
	private String credit_history;
	
	public Integer getCredit_score() {
		return credit_score;
	}
	public void setCredit_score(Integer credit_score) {
		this.credit_score = credit_score;
	}
	public String getCredit_history() {
		return credit_history;
	}
	public void setCredit_history(String credit_history) {
		this.credit_history = credit_history;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getSsn() {
		return ssn;
	}
	public void setSsn(Integer ssn) {
		this.ssn = ssn;
	}
	
	public String toString()
	{
		return "----name="+name+":ssn="+ssn+":credit_score="+credit_score+":credit_history="+credit_history+"------------";
	}
}